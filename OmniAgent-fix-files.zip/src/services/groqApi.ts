/**
 * Frontend chat service — talks to the same-origin /api/chat proxy.
 *
 * The Groq API key lives ONLY on the server (Vercel env var GROQ_API_KEY).
 * Never put API keys in frontend code — anything shipped to the browser
 * is public.
 */

const CHAT_ENDPOINT = '/api/chat';
const DEFAULT_MODEL = 'llama-3.3-70b-versatile';

export interface GroqMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export async function queryGroqAPI(
  messages: GroqMessage[],
  systemPrompt?: string,
  model: string = DEFAULT_MODEL
): Promise<{ text: string; reasoning?: string }> {
  try {
    const response = await fetch(CHAT_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages, systemPrompt, model: model || DEFAULT_MODEL }),
    });

    let data: any = {};
    try {
      data = await response.json();
    } catch {
      // non-JSON response (e.g. proxy / 404 page)
    }

    if (!response.ok) {
      throw new Error(data.error || `Chat service returned status ${response.status}`);
    }

    return {
      text: data.text || 'No response generated.',
      reasoning: `Answered live by ${data.model || model || DEFAULT_MODEL}.`,
    };
  } catch (error: any) {
    console.error('Chat service error:', error);
    // Honest error — never fake an AI answer.
    return {
      text: `I couldn't reach the AI service right now (${error?.message || 'network error'}). If this keeps happening, check that GROQ_API_KEY is set in the Vercel project settings and redeploy.`,
      reasoning: 'AI service unreachable — no response was generated.',
    };
  }
}
