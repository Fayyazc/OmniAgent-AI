/**
 * POST /api/pc-command — desktop-agent command endpoint (honest stub).
 *
 * There is currently no paired desktop agent, so this endpoint reports
 * its real status instead of pretending commands execute. When a desktop
 * companion app is built, implement pairing + command dispatch here.
 *
 * Request body: { action: string, ...params }
 * Response:     { ok: true, connected: false, message: string, diagPath: null }
 */

export default async function handler(req: any, res: any) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed. Use POST.' });
  }

  const action = req.body?.action || 'unknown';

  return res.status(200).json({
    ok: true,
    connected: false,
    action,
    diagPath: null,
    message:
      'Desktop agent is not paired. Received action "' +
      action +
      '" but there is no desktop companion connected to execute PC commands. Pair the OmniAgent desktop app to enable this feature.',
  });
}
