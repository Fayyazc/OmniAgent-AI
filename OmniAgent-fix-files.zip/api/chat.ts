/**
 * POST /api/chat — secure Groq proxy for the OmniAgent OS frontend.
 *
 * The browser never sees the Groq API key. Set GROQ_API_KEY in
 * Vercel → Project → Settings → Environment Variables, then redeploy.
 *
 * Request body: { messages: [{role, content}], systemPrompt?: string, model?: string }
 * Response:     { text: string, model: string }  or  { error: string }
 */

const GROQ_ENDPOINT = 'https://api.groq.com/openai/v1/chat/completions';
const DEFAULT_MODEL = 'llama-3.3-70b-versatile';

interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export default async function handler(req: any, res: any) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed. Use POST.' });
  }

  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey) {
    return res.status(500).json({
      error:
        'GROQ_API_KEY is not set on the server. Add it in Vercel → Settings → Environment Variables and redeploy.',
    });
  }

  const body = req.body || {};
  const messages: ChatMessage[] = Array.isArray(body.messages) ? body.messages : [];
  if (messages.length === 0) {
    return res.status(400).json({ error: 'Request body must include a non-empty "messages" array.' });
  }

  const model: string = body.model || DEFAULT_MODEL;
  const fullMessages: ChatMessage[] = [
    {
      role: 'system',
      content:
        body.systemPrompt ||
        'You are OmniAgent AI, an enterprise-grade AI Employee SaaS assistant. Provide helpful, structured, concise, and executive-ready output.',
    },
    ...messages,
  ];

  try {
    const groqRes = await fetch(GROQ_ENDPOINT, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model,
        messages: fullMessages,
        temperature: 0.7,
        max_tokens: 2048,
      }),
    });

    if (!groqRes.ok) {
      const errText = await groqRes.text();
      return res
        .status(502)
        .json({ error: `Groq API error ${groqRes.status}: ${errText.slice(0, 300)}` });
    }

    const data = await groqRes.json();
    const reply: string = data.choices?.[0]?.message?.content || 'No response generated.';
    return res.status(200).json({ text: reply, model });
  } catch (err: any) {
    return res.status(502).json({ error: `Could not reach the Groq API: ${err?.message || err}` });
  }
}
